var config = {
    createDB: {
        host: "localhost",
        user: "sunday",
        password: "secretWeb.vip@tesaFollowers1"
    },

    DBcreated: {
        host: "localhost", // 3.86.102.4
        port: 3306, // delete for localhost
        user: "sunday", // root for localhost
        database: "tesafollowers", // tesaFollowers -> for local machine
        // password: "" // secretWeb.vip@tesaFollowers1 -> for cloud
        password: "secretWeb.vip@tesaFollowers1" // secretWeb.vip@tesaFollowers1 -> for cloud
        // password: "socialAudience.club@1" // socialAudience.club@1 -> for socialaudience.club cloud
    },

    hostState: {
        siteName: ""
    }

}

export default config;
