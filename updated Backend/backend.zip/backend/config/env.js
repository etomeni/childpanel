const envData = {
    secretForToken: "RgUkXp2s5v8x/A?D(G+KbPeShVmYq3t6w9z$B&E)H@McQfTjWnZr4u7x!A%D*F-J",
}

export default envData;